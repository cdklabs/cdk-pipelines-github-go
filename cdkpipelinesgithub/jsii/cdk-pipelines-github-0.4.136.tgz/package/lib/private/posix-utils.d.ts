export declare function posixPath(windowsOrPosixPath: string): string;
